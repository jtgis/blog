# Hello World

Welcome to **My Minimal Blog**. This is a sample post written in *Markdown*.

- Edit this file to change the content.
- Or add a new file in `posts/` and an entry in `posts.json`.

```
# Sample code block
print("Hello, world!")
```

> Tip: Everything is set in a monospaced font on a clean white page.
