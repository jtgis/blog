# Second Post

This is another example. You can include links like
[GitHub Pages](https://pages.github.com) and inline `code`.

1. Add your `.md` file into the `posts/` folder
2. Add a record to `posts.json`
3. Commit and push
