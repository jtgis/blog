# Photo Entry

Here's a post that contains an image.

![Sample Photo](sample.jpg)

Looks good on the homepage preview too.
